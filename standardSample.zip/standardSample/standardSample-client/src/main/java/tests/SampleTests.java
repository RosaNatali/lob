package tests;

import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import entities.*;
import services.SampleServicesLocal;

public class SampleTests {

	public static void main(String[] args) throws NamingException
	{
		String appName="standardSample-ear";
		String moduleEJB="standardSample-ejb";
		String implName="SampleServices";
		String interfaceName=SampleServicesLocal.class.getCanonicalName();
		String jndiName=appName + "/" + moduleEJB + "/" + implName + "!" + interfaceName;

		Context ctx = new InitialContext();
		SampleServicesLocal ssr = (SampleServicesLocal) ctx.lookup(jndiName);
		
		
//		Engineer e1 = new Engineer("Sarsoura A", 1000000.0);
//		ssr.addUser(e1);
//		Engineer e2 = new Engineer("Sarsoura B", 2000000.0);
//		ssr.addUser(e2);
//		Engineer e3 = new Engineer("Sarsoura C", 3000000.0);
//		ssr.addUser(e3);
//		Engineer e4 = new Engineer("Sarsoura D", 4000000.0);
//		ssr.addUser(e4);
//		Engineer e5 = new Engineer("Sarsoura E", 5000000.0);
//		ssr.addUser(e5);
//		Engineer e6 = new Engineer("Sarsoura F", 6000000.0);
//		ssr.addUser(e6);
//	
//		Doctor d1 = new Doctor("Sousou A", "Surgey");
//		ssr.addUser(d1);
//		Doctor d2 = new Doctor("Sousou B", "Pediatrician");
//		ssr.addUser(d2);
		
//		User u = ssr.findUserById(9);
//		ssr.deleteUser(u);
		
//		u.setName("aaaaaaaaaaaaa");
//		ssr.updateUser(u);
		
		Entreprise entr1 = new Entreprise("HP");
		ssr.addEntreprise(entr1);
		Entreprise entr2 = new Entreprise("Cartagene");
		ssr.addEntreprise(entr2);		
		
		
		User u1 = ssr.findUserById(1);
		User u2 = ssr.findUserById(2);
		User u3 = ssr.findUserById(3);
		User u4 = ssr.findUserById(4);
		User u5 = ssr.findUserById(5);
		User u6 = ssr.findUserById(7);
		User u7 = ssr.findUserById(10);
		
		Entreprise e1 = ssr.findEntrepriseById(1);
		Entreprise e2 = ssr.findEntrepriseById(2);
		
//		ssr.affectUserToEntreprise(u1, e1);
//		ssr.affectUserToEntreprise(u2, e1);
//		ssr.affectUserToEntreprise(u3, e1);
//		ssr.affectUserToEntreprise(u4, e1);
//		ssr.affectUserToEntreprise(u5, e1);
//		ssr.affectUserToEntreprise(u6, e2);
//		ssr.affectUserToEntreprise(u7, e2);
//		
		List<User> les = ssr.findAllUsersOnEntreprise(e1.getEntrepriseId());
		List<User> lds = ssr.findAllUsersOnEntreprise(e2.getEntrepriseId());
		
		for(User e : les)
		{
			System.out.println("employees of HP" + e.getName());
		}
		
		for(User e : lds)
		{
			System.out.println("employees of Cartagene" + e.getName());
		}
		
//		ssr.disaffectUserFromEntreprise(u5, e1);
		
		ssr.disaffectAllUsersFromEntreprise(les, e1);

	}

}
