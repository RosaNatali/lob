package entities;

import java.io.Serializable;
import java.lang.Double;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Engineer
 *
 */
@Entity

public class Engineer extends User implements Serializable {

	
	private Double salary;
	private static final long serialVersionUID = 1L;

	public Engineer() {
		super();
	}   
	
	
	
	public Engineer(String name, Double salary) {
		super(name);
		this.salary = salary;
	}



	public Double getSalary() {
		return this.salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
   
}
