package entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class UserEntrepriseId implements Serializable
{
	private Integer userId;
	private Integer entrepriseId;
	
	public UserEntrepriseId()
	{
		super();
	}
	public UserEntrepriseId(Integer userId, Integer entrepriseId) {
		super();
		this.userId = userId;
		this.entrepriseId = entrepriseId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getEntrepriseId() {
		return entrepriseId;
	}
	public void setEntrepriseId(Integer entrepriseId) {
		this.entrepriseId = entrepriseId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entrepriseId == null) ? 0 : entrepriseId.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserEntrepriseId other = (UserEntrepriseId) obj;
		if (entrepriseId == null) {
			if (other.entrepriseId != null)
				return false;
		} else if (!entrepriseId.equals(other.entrepriseId))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	
}
