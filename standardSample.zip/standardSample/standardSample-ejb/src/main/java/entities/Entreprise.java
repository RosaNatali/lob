package entities;

import java.io.Serializable;
import java.lang.Integer;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Entreprise
 *
 */
@Entity

public class Entreprise implements Serializable {

	   
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer entrepriseId;
	private String libelle;
	
	@OneToMany(mappedBy="entreprise")
	private List<UserEntreprise> lues;
	
	private static final long serialVersionUID = 1L;

	public Entreprise() {
		super();
	}   
	
	

	public Entreprise(String libelle) {
		this.libelle = libelle;
	}



	public Integer getEntrepriseId() {
		return this.entrepriseId;
	}

	public void setEntrepriseId(Integer entrepriseId) {
		this.entrepriseId = entrepriseId;
	}   
	
	public String getLibelle() {
		return libelle;
	}



	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}



	public List<UserEntreprise> getLues() {
		return lues;
	}
	public void setLues(List<UserEntreprise> lues) {
		this.lues = lues;
	}
   
	
}
