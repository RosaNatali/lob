package entities;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: User
 *
 */
@Entity

public class User implements Serializable {

	   
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer userId;
	private String name;
	
	@OneToMany(mappedBy="user")
	private List<UserEntreprise> lues;
	
	private static final long serialVersionUID = 1L;

	
	
	public User(String name) {
		super();
		this.name = name;
	}
	public User() {
		super();
	}   
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}   
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public List<UserEntreprise> getLues() {
		return lues;
	}
	public void setLues(List<UserEntreprise> lues) {
		this.lues = lues;
	}
	
	
}
