package entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: UserEntreprise
 *
 */
@Entity
public class UserEntreprise implements Serializable {

	@EmbeddedId
	private UserEntrepriseId uei;
	
	@ManyToOne
	@JoinColumn(name="userId", updatable=false, insertable=false, nullable=false)
	private User user;
	
	@ManyToOne
	@JoinColumn(name="entrepriseId", updatable=false, insertable=false, nullable=false)
	private Entreprise entreprise;
	
	private static final long serialVersionUID = 1L;

	public UserEntreprise() {
		super();
	}
	
	public UserEntreprise(User user, Entreprise entreprise) 
	{
		this.user = user;
		this.entreprise = entreprise;
		this.uei = new UserEntrepriseId(user.getUserId(), entreprise.getEntrepriseId());
	}

	public UserEntrepriseId getUei() {
		return uei;
	}

	public void setUei(UserEntrepriseId uei) {
		this.uei = uei;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Entreprise getEntreprise() {
		return entreprise;
	}

	public void setEntreprise(Entreprise entreprise) {
		this.entreprise = entreprise;
	}
	
	
	
   
}
