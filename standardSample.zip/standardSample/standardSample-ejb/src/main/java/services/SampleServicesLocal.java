package services;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;

import entities.Entreprise;
import entities.User;

@Remote
public interface SampleServicesLocal
{
	public void addUser(User u);	
	public void updateUser(User u);
	public void deleteUser(User u);
	public User findUserById(Integer id);
	public List<User> findAllUsers();
	
	public void addEntreprise(Entreprise e);	
	public void updateEntreprise(Entreprise e);
	public void deleteEntreprise(Entreprise e);
	public Entreprise findEntrepriseById(Integer id);
	public List<Entreprise> findAllEntreprises();
	
	public void affectUserToEntreprise(User u, Entreprise e);
	public void disaffectUserFromEntreprise(User u, Entreprise e);
	public List<User> findAllUsersOnEntreprise(Integer id);
	public void disaffectAllUsersFromEntreprise(List<User> lus, Entreprise e);
	
}
