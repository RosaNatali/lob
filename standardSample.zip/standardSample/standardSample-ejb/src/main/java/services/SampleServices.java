package services;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.Entreprise;
import entities.User;
import entities.UserEntreprise;
import entities.UserEntrepriseId;

@Stateless
public class SampleServices implements SampleServicesLocal
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public void addUser(User u)
	{
		em.persist(u);
	}

	@Override
	public void updateUser(User u)
	{
		em.merge(u);
	}

	@Override
	public void deleteUser(User u)
	{
		em.remove(em.merge(u));
	}

	@Override
	public User findUserById(Integer id)
	{
		return em.find(User.class, id);
	}

	@Override
	public List<User> findAllUsers()
	{
		return em.createQuery("select u from User u", User.class).getResultList();
	}

	@Override
	public void addEntreprise(Entreprise e)
	{
		em.persist(e);
	}

	@Override
	public void updateEntreprise(Entreprise e)
	{
		em.merge(e);
	}

	@Override
	public void deleteEntreprise(Entreprise e)
	{
		em.remove(e);
	}

	@Override
	public Entreprise findEntrepriseById(Integer id)
	{
		return em.find(Entreprise.class, id);
	}

	@Override
	public List<Entreprise> findAllEntreprises()
	{
		return em.createQuery("select u from Entreprise u", Entreprise.class).getResultList();
	}

	@Override
	public void affectUserToEntreprise(User u, Entreprise e)
	{
		UserEntreprise ue = new UserEntreprise(u, e);
		em.merge(ue);
	}

	@Override
	public void disaffectUserFromEntreprise(User u, Entreprise e)
	{
		em.remove(em.find(UserEntreprise.class, new UserEntrepriseId(u.getUserId(), e.getEntrepriseId())));
	}

	@Override
	public void disaffectAllUsersFromEntreprise(List<User> lus, Entreprise e)
	{
		for(User u : lus)
		{
			em.remove(em.find(UserEntreprise.class, new UserEntrepriseId(u.getUserId(), e.getEntrepriseId())));
		}
	}

	
	@Override
	public List<User> findAllUsersOnEntreprise(Integer id)
	{
		return em.createQuery("select u FROM User u JOIN u.lues ues WHERE ues.entreprise.entrepriseId=:p", User.class).setParameter("p", id).getResultList();
	}
	
}
